module.exports = {
    MONGOURI: "mongodb+srv://Deepak:y0sxXuLeKGDPIZ1B@cluster0.roied.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    JWT_SECURE: "Gc26$G46f/WD",
    SUPER_USER_ID: "62322a4ae7d03248e14b2fdd"
}